package com.nntc.my;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    String[] list = {"Item", "Item", "Item", "Item", "Item", "Item", "Item", "Item", "Item", "Item", "Item", "Item"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView listView = (ListView) findViewById(R.id.listView_1);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, list);
        listView.setAdapter(arrayAdapter);
    }

    public void toActivity(View view){
        Intent intent_1 = new Intent(this, MainActivity2.class);
        startActivity(intent_1);
    }

    public void sendMessage(View view){
        Intent intent_2 = new Intent(this, MainActivity2.class);
        EditText editText = (EditText) findViewById(R.id.editText);
        intent_2.putExtra("ms", editText.getText().toString());
        startActivity(intent_2);
    }

//    public void sendMessage(View view){
//        Intent intent = new Intent(this, MainActivity3.class);
//        EditText editText = (EditText) findViewById(R.id.editText);
//        intent.putExtra("message", editText.getText().toString());
//        startActivity(intent);
//    }

    public void toActivity_1(View view){
        Intent intent_3 = new Intent(this, MainActivity3.class);
        startActivity(intent_3);
    }

    public void sendMessage_2(View view){
        Intent intent_4 = new Intent(this, MainActivity3.class);
        EditText editText_1 = (EditText) findViewById(R.id.editText);
        intent_4.putExtra("sendMessage_2", editText_1.getText().toString());
        startActivity(intent_4);
    }
}